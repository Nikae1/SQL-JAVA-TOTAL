package loader;

import client.TaskManagement;
import client.Userapp;
import server.beans.TodoBean;

public class Loader {
	
	public static void main(String[] args) {
		
		new Userapp();
		
	}

}
