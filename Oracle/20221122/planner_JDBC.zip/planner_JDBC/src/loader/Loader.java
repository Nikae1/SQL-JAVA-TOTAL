package loader;

import client.UserApp;

public class Loader {

	public static void main(String[] args) {
		new UserApp();
	}

}
