package server;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import server.beans.AccessHistoryBean;
import server.beans.MemberBean;

/* 로그인, 로그아웃, 접속로그기록 */
public class Auth {
	
	public Auth() {
		
	}
		
	public boolean accessCtl(String clientData) {
		MemberBean member = (MemberBean)this.setBean(clientData);
		DataAccessObject dao = new DataAccessObject();
		
		member.setFileIdx(0);
		ArrayList<MemberBean> memberList = dao.readDatabase(member.getFileIdx());
		AccessHistoryBean historyBean;
		boolean accessResult = false;
		
		if(this.compareAccessCode(member.getAccessCode(), memberList)) {
			if(this.isAuth(member, memberList)) {
				/* (fileIdx=1) accessCode, (date=> yyyyMMddHHmmss), (accessType=1) */
				historyBean= new AccessHistoryBean();
				historyBean.setFileIdx(1);
				historyBean.setAccessCode(member.getAccessCode());
				historyBean.setAccessDate(this.getDate(false));
				historyBean.setAccessType(1);
				
				accessResult = dao.writeAccessHistory(historyBean);
			}
		}
		
		return accessResult;
	}
	
	public void accessOut(String clientData) {
		DataAccessObject dao = new DataAccessObject();
		AccessHistoryBean history = (AccessHistoryBean)this.setBean(clientData);
		history.setFileIdx(1);
		history.setAccessDate(this.getDate(false));
		history.setAccessType(-1);
		
		dao.writeAccessHistory(history);
	}
	
	private String getDate(boolean isDate) {
		String pattern = (isDate)? "yyyyMMdd": "yyyyMMddHHmmss";
		return LocalDateTime.now().format(DateTimeFormatter.ofPattern(pattern));
	}
	
	private Object setBean(String clientData) {
		Object object = null;
		String[] splitData = clientData.split("&");
		switch(splitData[0].split("=")[1]) {
		case "-1":
			object = new AccessHistoryBean();
			((AccessHistoryBean)object).setAccessCode(splitData[1].split("=")[1]);
			break;
		case "1":
			object = new MemberBean();
			((MemberBean)object).setAccessCode(splitData[1].split("=")[1]);
			((MemberBean)object).setSecretCode(splitData[2].split("=")[1]);

			break;
		}
				
		return object;
	} 
	
	/* AccessCode 존재여부 판단 */
	private boolean compareAccessCode(String code, ArrayList<MemberBean> memberList) {
		boolean result = false;
		for(MemberBean member : memberList) {
			if(code.equals(member.getAccessCode())) {
				result = true;
				break;
			}
		}

		return result;
	}
	
	/* AccessCode와 SecretCode의 비교 */
	private boolean isAuth( MemberBean member, ArrayList<MemberBean> memberList) {
		boolean result = false;
		for(MemberBean memberInfo : memberList) {
			if(member.getAccessCode().equals(memberInfo.getAccessCode())) {
				if(member.getSecretCode().equals(memberInfo.getSecretCode())) {
					result = true;
					break;
				}
			}
		}
		return result;
	}
}
