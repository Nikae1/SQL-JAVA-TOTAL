package server;

import java.io.BufferedReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;

import server.beans.AccessHistoryBean;
import server.beans.MemberBean;
import server.beans.ToDoBean;

/* Data File과의 통신 */
public class DataAccessObject {
	
	//private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	public DataAccessObject() {
		
	}
	// CONNECTION CREATION 
	public Connection openConnection() {
		
		Connection connection = null;
		try {
			//Class.forName()의 용도는 컴파일 타임에 직접적인 참조 없이 런타임에 동적으로 클래스를 로드하기 위함이다. 
			//런타임(Runtime)과 컴파일타임(Compiletime)은 소프트웨어 프로그램개발의 서로 다른 두 계층의 차이를 설명하기 위한 용어이다. 프로그램을 생성하기 위해 개발자는 첫째로 소스코드를 작성하고 컴파일이라는 과정을 통해 기계어코드로 변환 되어 실행 가능한 프로그램이 되며, 이러한 편집 과정을 컴파일타임(Compiletime) 이라고 부른다.
            //컴파일과정을 마친 프로그램은 사용자에 의해 실행되어 지며, 이러한 응용프로그램이 동작되어지는 때를 런타임(Runtime)이라고 부른다.
			Class.forName("oracle.jdbc.driver.OracleDriver");//오라클 드라이버가 메모리에 올라옴.
			connection = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.89:1521:xe","LJH","1234");
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Error :OracleDriver None");
			e.printStackTrace();
		}
		
		
		return connection;
	}
	public int isMemberId(Connection connection, MemberBean member ) {
		
		String query = "SELECT COUNT(*) AS ISMRID FROM TM WHERE MR_ID=?";
		rs =null;
		// 'JJJ'대신 ? PREPAREDSTATEMENT 사용
		int result = 0;
		
	    try {
			this.ps=connection.prepareStatement(query);
			ps.setNString(1, member.getAccessCode());
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				result = rs.getInt("ISMRID");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	public int isSame(Connection connection,MemberBean member ) {
		String query = "SELECT COUNT(*) AS ISACCESS FROM TM WHERE MR_ID=? AND MR_PWD = ?";
		rs = null;
		int result =0;
		 try {
				this.ps=connection.prepareStatement(query);
				ps.setNString(1, member.getAccessCode());
				ps.setNString(2, member.getSecretCode());
				rs=ps.executeQuery();
				
				while(rs.next())
				{
					result = rs.getInt("ISACCESS");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return result;
	}
	public int insAccessHistory(Connection connection,MemberBean member) {
		String query = "INSERT INTO AH(AH_MRID, AH_DATE, AH_STATE) VALUES(?,DEFAULT,?)";
		int result =0;
		 try {
				this.ps=connection.prepareStatement(query);
				ps.setNString(1, member.getAccessCode());
				ps.setInt(2, member.getAccessType());
				result = ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return result;
	}
	public void closeConnection(Connection connection) {
		try {
			if(!connection.isClosed()) {
				if(this.rs != null && !this.rs.isClosed()) this.rs.close();
				if(this.ps != null && !this.ps.isClosed()) this.ps.close();
				connection.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public boolean transaction(boolean tran,Connection connection) {
	    boolean result = false;
		try {
			if(tran)
			{
				connection.commit();	
				result=true;
			}
			else
				connection.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return result;
	}
	public void modifyTranStatus(Connection connection, boolean status)
	{
		try {
			if(connection != null && !connection.isClosed()) {
				connection.setAutoCommit(status);
			}
		} catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public ArrayList<ToDoBean> getToDoDate(Connection connection, ToDoBean todo){
		ArrayList<ToDoBean> toDoList = new ArrayList<ToDoBean>();
		ToDoBean tb = null;
		String query = "SELECT TO_CHAR(TD_DATE, 'YYYYMMDD') AS STARTDATE, "
				+ "TO_CHAR(TD_EDATE, 'YYYYMMDD') AS ENDDATE "
				+ "FROM TD "
				+ "WHERE TD_MRID = ? AND TO_CHAR(TD_DATE, 'YYYYMM') = ?";
		
		try {
			this.ps = connection.prepareStatement(query);
			this.ps.setNString(1, todo.getAccessCode());
			this.ps.setNString(2, todo.getStartDate().substring(0,6));
			
			this.rs =  this.ps.executeQuery();
			while(this.rs.next()) {
				tb = new ToDoBean();
				tb.setStartDate(this.rs.getNString("STARTDATE"));
				tb.setEndDate(this.rs.getNString("ENDDATE"));
				toDoList.add(tb);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return toDoList;
	}
	
	public int modToDoList(Connection connection, ToDoBean todo){
		String query= new String();
		int result =0;
		String[] dno= todo.getDetailno().split(",");
		String[] dcontents = todo.getDetailcontents().split(",");
		//dno, dcontents에는 수정할 번호와 수정할 내용이 들어있습니다. ex) 수정번호 1번이면 시작날짜, 수정할 시작날짜
		//수정번호와 수정내용을 가지고 query를 만들어줬습니다.
		query="UPDATE TODODBA.TODO SET ";
		for(int i=0; i<dno.length; i++)
		{
			if(dno[i].equals("1")) //startdate
			{
				query+="TD_DATE=TO_DATE(?,'YYYYMMDDHH24MISS') ";
			}else if(dno[i].equals("2")) //enddate
			{
				query+="TD_EDATE=TO_DATE(?,'YYYYMMDDHH24MISS') ";
			}else if(dno[i].equals("3")) //contents
			{
				query+="TD_CONTENT=? ";
			}else if(dno[i].equals("4")) //visibletype
			{
				query+="TD_STATE=? ";
			}else if(dno[i].equals("5")) //active
			{
				query+="TD_ACTIVATION=? ";
			}else if(dno[i].equals("6")) //comments
			{
				query+="TD_FEEDBACK=? ";
			}
			if(i!=dno.length-1)
				query+=",";
		}
		
		query += "WHERE TD_MRID=? AND TO_CHAR(TD_DATE,'YYYYMMDDHH24MISS')=? AND TO_CHAR(TD_EDATE,'YYYYMMDDHH24MISS')=?"
				+ " AND TD_CONTENT = ?";
		
		int count=1;
		
		 try {
			    //수정할 목록만큼 ps에 setting해줬습니다.
				this.ps=connection.prepareStatement(query);
				for(int i=0; i<dno.length; i++)
				{
					ps.setNString(count, dcontents[count-1]);
					count++;
				}
				ps.setNString(count++, todo.getAccessCode());
				ps.setNString(count++, todo.getStartDate());
				ps.setNString(count++, todo.getEndDate());
				ps.setNString(count++, todo.getContents());
				result = ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return result;	
	}
	// 호원 유저 입력값을 데이터 베이스에 올려 업데이트 하는 메서드
	public int setToDoList(Connection connection, ToDoBean todo){
		String query;
		query = "INSERT INTO TODODBA.TODO(TD_MRID,TD_DATE,TD_EDATE,TD_FEEDBACK,TD_CONTENT,TD_STATE,TD_ACTIVATION)"
				+ " VALUES(?,TO_DATE(?,'YYYYMMDDHH24MISS'),TO_DATE(?,'YYYYMMDDHH24MISS'),DEFAULT,?,DEFAULT,DEFAULT)";
		
		int result =0;
		 try {
				this.ps=connection.prepareStatement(query);
				ps.setNString(1, todo.getAccessCode());
				ps.setNString(2, todo.getStartDate());
				ps.setNString(3, todo.getEndDate());
				ps.setNString(4, todo.getContents());
				result = ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return result;	
	}
	public ArrayList<ToDoBean> getToDoList(Connection connection, ToDoBean todo){
		ArrayList<ToDoBean> toDoList = new ArrayList<ToDoBean>();
		ToDoBean tb = null;
		String query;
		boolean[] bol = {true,true,true};
		
	
		query = "SELECT * FROM TODODBA.TODOLIST "
				+ "WHERE MRID = ? AND "
				+ "(GREATEST(?,SUBSTR(STARTDATE, 1, 8))  <="
				+ "        LEAST(?,SUBSTR(ENDDATE, 1, 8)) )"
				+ (todo.getVisibleType() == null? "":"  AND ACTIVE = ?");
		try {
			this.ps = connection.prepareStatement(query);
			
			this.ps.setNString(1, todo.getAccessCode());		
			this.ps.setNString(2, todo.getStartDate());
			this.ps.setNString(3, todo.getEndDate());
			if(todo.getVisibleType() != null)
			{
				this.ps.setNString(4, todo.getVisibleType());
			}	
			
			
			this.rs =  this.ps.executeQuery();
			while(this.rs.next()) {
				tb = new ToDoBean();
				tb.setAccessCode(this.rs.getNString("ACCESSCODE"));
				tb.setStartDate(this.rs.getNString("STARTDATE"));
				tb.setEndDate(this.rs.getNString("ENDDATE"));
				tb.setContents(this.rs.getNString("CONTENTS"));
				tb.setStatus(this.rs.getNString("STATUS"));
				tb.setActive(this.rs.getNString("ACTIVE").equals("A")? true:false);
				tb.setComments(this.rs.getNString("COMMENTS"));
				
				toDoList.add(tb);
			}
			
	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return toDoList;
		
	}
	private boolean duplicateCheck(ArrayList<ToDoBean> dayList, String compareValue) {
		boolean result = false;
		for(int listIdx=0; listIdx<dayList.size(); listIdx++) {
			if(compareValue.equals(dayList.get(listIdx).getStartDate())) {
				result = true;
				break;
			}
		}
		return result;
	}
}
