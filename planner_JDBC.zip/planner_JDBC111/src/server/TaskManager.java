package server;

import java.sql.Connection;
import java.time.LocalDate;
import java.util.ArrayList;

import server.beans.ToDoBean;

public class TaskManager {
	
	public TaskManager() {
		
	}
	
	/* 특정 계정의 특정 월의 할일이 등록되어 있는 날짜 리스트 가져오기*/
	public String getTodoDateCtl(String clientData) {
		ArrayList<ToDoBean> toDoList = null;
		DataAccessObject dao = new DataAccessObject();

		ToDoBean todo = ((ToDoBean)this.setBean(clientData));
		
		Connection connection = dao.openConnection();
		toDoList = dao.getToDoDate(connection,todo);
		//getToDoDate
		
		
		dao.closeConnection(connection);
		this.modifyToDoList(toDoList);
		return this.convertServerData(this.makeDayList(toDoList));	
	}
	
	public String getToDoListCtl(String clientData) {
		String result = null;
		DataAccessObject dao = new DataAccessObject();
		ToDoBean todo = ((ToDoBean)this.setBean(clientData));
		
		Connection connection = dao.openConnection();
		result = this.convertServerData2(dao.getToDoList(connection, todo));
		dao.closeConnection(connection);
		
		return result;
	}
	// 현우 유저 입력값을 셋빈에 보내 스플릿한 다음 DAO에 보내는 메서드
	public int setTodoListCtl(String clientData) {
		int result;
		DataAccessObject dao = new DataAccessObject();
		ToDoBean todo = ((ToDoBean)this.setBean(clientData));
		
		Connection connection = dao.openConnection();
		result = dao.setToDoList(connection,todo);
		dao.closeConnection(connection);
		
		return result;
	}
	public int modTodoListCtl(String clientData) {
		int result;
		DataAccessObject dao = new DataAccessObject();
		ToDoBean todo = ((ToDoBean)this.setBean(clientData));
		
		Connection connection = dao.openConnection();
		
		result = dao.modToDoList(connection,todo);
		dao.closeConnection(connection);
		
		return result;
	}
	private String convertServerData(ArrayList<Integer> list) {
		StringBuffer serverData = new StringBuffer();
		
		for(int day : list) {
			serverData.append(day + ":");
		}
		
		/* 마지막으로 추가된 항목 삭제 */
		if(serverData.length() != 0) {
			serverData.deleteCharAt(serverData.length()-1);
		}
		return serverData.toString();
	}
	private void modifyToDoList(ArrayList<ToDoBean> toDoList) {
		String date = null;
		for(ToDoBean todo : toDoList) {
			date= todo.getStartDate().substring(0,6);
			
			if(!date.equals(todo.getEndDate().substring(0,6))) {
				todo.setEndDate(date+ LocalDate.of(Integer.parseInt(date.substring(0, 4)), 
						Integer.parseInt(date.substring(4, 6)),	1).lengthOfMonth());
			}
		}
	}
	private ArrayList<Integer> makeDayList(ArrayList<ToDoBean> toDoList){
		ArrayList<Integer> dayList = new ArrayList<Integer>();
		boolean isSave;
		for(ToDoBean date : toDoList) {
			
			for(int dateIdx=Integer.parseInt(date.getStartDate().substring(6,8)); 
						dateIdx <= Integer.parseInt(date.getEndDate().substring(6,8)); 
						dateIdx++) {
				isSave = true;
				for(int listIdx=0; listIdx<dayList.size(); listIdx++) {

					if(dayList.get(listIdx) == dateIdx) {				
						isSave = false;
						break;
					}
				}
				if(isSave) dayList.add(dateIdx);
			}
		}
		return dayList;
	}
	private String convertServerData2(ArrayList<ToDoBean> list) {
		StringBuffer serverData = new StringBuffer();
		
		for(ToDoBean todo : list) {
			serverData.append(todo.getAccessCode() != null? todo.getAccessCode() + ",":"");
			serverData.append(todo.getStartDate() != null? todo.getStartDate() + "," :"");
			serverData.append(todo.getEndDate() != null? todo.getEndDate() + ",":"");
			serverData.append(todo.getContents() != null? todo.getContents() + ",":"");
			serverData.append(todo.getStatus() != null? todo.getStatus() + ",":"");
			serverData.append(todo.isActive()  + ",");
			serverData.append(todo.getComments() != null? todo.getComments() + ",":"");
			if(serverData.charAt(serverData.length()-1) == ',') {
				serverData.deleteCharAt(serverData.length()-1);
			}
			serverData.append(":");
		}
		
		if(serverData.length() > 0 &&  serverData.charAt(serverData.length()-1) == ':') {
			serverData.deleteCharAt(serverData.length()-1);
		}
		
		return serverData.toString();
	}
	private Object setBean(String clientData) {
		Object object = null;
		String[] splitData = clientData.split("&");
		switch(splitData[0].split("=")[1]) {
		case "9":
			object = new ToDoBean();
			((ToDoBean)object).setAccessCode(splitData[1].split("=")[1]);
			((ToDoBean)object).setStartDate(splitData[2].split("=")[1]);
			
			break;
		case "12":
			object = new ToDoBean();
			((ToDoBean)object).setAccessCode(splitData[4].split("=")[1]);
			((ToDoBean)object).setStartDate(splitData[1].split("=")[1]);
			((ToDoBean)object).setEndDate(splitData[2].split("=")[1]);
			String visibleType = splitData[3].split("=")[1];
			if(!visibleType.equals("T")) {
				((ToDoBean)object).setVisibleType(visibleType.equals("E")? "A": "I");
			}
			break;
		case "22":
			/*servicCode=22&startdate=20221106140000&endDate=20221106140000&contents=Programming&accessCode=LLL*/
			object = new ToDoBean();
			((ToDoBean)object).setAccessCode(splitData[4].split("=")[1]);
			((ToDoBean)object).setStartDate(splitData[1].split("=")[1]);
			((ToDoBean)object).setEndDate(splitData[2].split("=")[1]);
			((ToDoBean)object).setContents(splitData[3].split("=")[1]);	
			break;
		case "31":
			// [1]시작날짜, [2]끝날자, [3]CONTENT ,[4]TDETYPE, [5]ACTIVE , [6]COMMENT	
			/*servicCode=31&startdate=20221106140000&endDate=20221106140000&contents=Programming&accessCode=LLL*/
			object = new ToDoBean();
			((ToDoBean)object).setAccessCode(splitData[8].split("=")[1]);
			((ToDoBean)object).setStartDate(splitData[1].split("=")[1]);
			((ToDoBean)object).setEndDate(splitData[2].split("=")[1]);
			((ToDoBean)object).setContents(splitData[3].split("=")[1]);	
			((ToDoBean)object).setVisibleType(splitData[4].split("=")[1]);
			((ToDoBean)object).setActive((splitData[5].split("=")[1].equals("1"))? true :false);
			((ToDoBean)object).setComments(splitData[6].split("=")[1]);
			((ToDoBean)object).setDetailno(splitData[7].split("=")[1]);
			((ToDoBean)object).setDetailcontents(splitData[9].split("=")[1]);
			break;	
		}
			
		return object;
	} 
}
