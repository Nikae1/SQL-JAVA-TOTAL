package client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import server.ServerController;

public class TaskManagement {
	
	private ServerController server;
	private String[][] tlist;
	public TaskManagement() {
		server = new ServerController();
	}
	// 31 modify할때 달력출력에 대해서도 case 추가
	public Object taskController(int selection, String accessCode, int month) {
		Object result = null;
		switch(selection) {
		case 11: case 21: case 31:
			result = this.makeTaskCalendarCtl(accessCode, month);
			break;
		}
		
		return result;
	}
	// 22, 31 할일등록, 수정에 대해서도 case 추가
	public Object taskController(String clientData) {
		Object result = null;
		switch(clientData.split("&")[0].split("=")[1]) {
		case "12":
			result = this.getTaskListCtl(clientData);
			break;
		case "22":
			/*servicCode=22&startdate=20221106140000&endDate=20221106140000&contents=Programming&accessCode=LLL*/
			result = this.TaskRegistrationCtl(clientData);
			break;
		case "31":
			result = this.setModifyTaskCtl(clientData);
			break;
		case "41":
			result = this.getTaskStatCtl(clientData);
			break;
		}
		return result;
	}

	private Object makeTaskCalendarCtl(String accessCode, int month) {	
		LocalDate today = LocalDate.now().plusMonths(month);
		
		int[] taskDays = this.getTaskDays(this.server.controller("serviceCode=9&accessCode="+ accessCode + 
						 "&date=" + today.format(DateTimeFormatter.ofPattern("yyyyMM"))));

		return this.makeCalendar(taskDays, today);
	}
	
	
	private Object getTaskListCtl(String clientData) {
		String serverData = this.server.controller(clientData);
		String[] record=serverData.split(":");
		
		if(serverData.equals("")) setnullInfo();
		return !serverData.equals("")? this.makeTodoList(this.convertTwoArray(record)): "\n   등록된 일정이 없습니다.\n";
		
	}
	//할 일 목록이 없을때 이전 불러온 정보가 있을때를 초기화해주는 부분입니다.
	public void setnullInfo() {
		tlist=null;
	}

	private Object TaskRegistrationCtl(String clientData) {
		
		return (this.server.controller(clientData));
	}
	/* 등록된 할일 수정하기 */
	//서버컨트롤러에 보내주는 부분
	private Object setModifyTaskCtl(String clientData) {
		return (this.server.controller(clientData));
	}

	private Object getTaskStatCtl(String clientData) {
		return null;
	}
	//할 일들을 tlist란 필드 변수에 저장하기.
	public Object getInfo() {
		
		Object obj= tlist;
		return obj;
	}
	public void setInfo(String[][] toDoList)
	{
		tlist=toDoList;
	}
	private String makeTodoList(String[][] toDoList) {
		StringBuffer buffer = new StringBuffer();
		
		String now;
		int itemCount = 0, beginIdx = 0;
		while(true) {
			now = toDoList[beginIdx][0];
			itemCount = this.itemCount(toDoList, now);
				
			buffer.append("   [ " + now.substring(0, 4) +". "+ now.substring(4, 6) + ". " + now.substring(6) + " ]");
			buffer.append("  Total " + itemCount + " Items\n");
			buffer.append("   ─────────────────────────────────────────────────────\n");
			buffer.append("     ITEM\n");
			buffer.append("     └─   Start Date\tEnd Date\tProcess\tEnable\n");
			buffer.append("   ─────────────────────────────────────────────────────\n");
			
			for(int itemIdx=beginIdx; itemIdx<(beginIdx+itemCount); itemIdx++) {
				buffer.append(itemIdx>beginIdx?"     ------------------------------------------------\n":"");		
				buffer.append("     " + itemIdx);
				buffer.append(" " + toDoList[itemIdx][3] + "\n");
				buffer.append("     └─   " + this.formattedDate(toDoList[itemIdx][1]) + "\t" );
				buffer.append(this.formattedDate(toDoList[itemIdx][2]) + "\t");
				buffer.append(this.processingValue(toDoList[itemIdx][4]) + "\t");
				buffer.append(toDoList[itemIdx][5].equals("true")? "활성 \n":"삭제\n");
				buffer.append((!toDoList[itemIdx][6].equals("NONE"))?"     └─   " + toDoList[itemIdx][6]+ "\n":"");
				toDoList[itemIdx][0] = itemIdx+"";
			}
			buffer.append("   ─────────────────────────────────────────────────────\n");
			
			if((beginIdx+itemCount) == toDoList.length) break;
			buffer.append("\n");
			beginIdx += itemCount;
		}
		setInfo(toDoList);
		return buffer.toString();
	}
	
	private String[][] convertTwoArray(String[] record){
		String[][] toDoList = null;
		String temp;
		
		for(int idx=0; idx<record.length ; idx++) {
			if(idx != record.length-1) {
				for(int subIdx=idx+1; subIdx<record.length ; subIdx++) {
					if(Integer.parseInt(record[idx].substring(0, 8)) > Integer.parseInt(record[subIdx].substring(0, 8))) {
						temp = record[idx];
						record[idx] = record[subIdx];
						record[subIdx] = temp;
					}
				}
			}
		}
		
		toDoList = new String[record.length][];
		for(int idx=0; idx<record.length ; idx++) {
			toDoList[idx] = record[idx].split(",");
		}
		return toDoList;
	}
	
	private String processingValue(String text) {
		String result = null;
		switch(text) {
		case "E":
			result = "진행전";
			break;
		case "P":
			result = "보류 ";
			break;
		case "I":
			result = "진행중";
			break;
		case "C":
			result = "완료 ";
			break;
		}
		return result;
	}
	private String formattedDate(String date) {
		return date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6, 8);
	}
	private int itemCount(String[][] list, String compareValue) {
		int itemCount = 0;
		for(int idx=0; idx<list.length; idx++) {
			if(compareValue.equals(list[idx][0])) {
				itemCount += 1;
			}
		}
		return itemCount;
	}
		
	private int[] getTaskDays(String serverData) {
		int[] taskDays = null;
		if(!serverData.equals("")) {
			String[] splitData = serverData.split(":");
			taskDays = new int[splitData.length];

			for(int idx=0; idx<taskDays.length; idx++) {
				taskDays[idx] = Integer.parseInt(splitData[idx]);
			}
		}
		return taskDays;
	}
	
	private String makeCalendar(int[] taskDays, LocalDate today) {
		StringBuffer calendar = new StringBuffer();
		int dayOfWeek = LocalDate.of(today.getYear(), today.getMonthValue(), 1).getDayOfWeek().getValue();		
		int lastDay = today.lengthOfMonth();
		boolean isTask = false;
		
		dayOfWeek = (dayOfWeek==7)? 1:dayOfWeek+1;
		
		calendar.append("\n");
		calendar.append("    +++++++++++ Previous  [ " + today.format(DateTimeFormatter.ofPattern("yyyy. MM.")) + " ]  Next +++++++++++\n");
		calendar.append("        SUN    MON    TUE    WED    THU    FRI    SAT\n");
		calendar.append("      ");
		for(int dayIdx=1-(dayOfWeek-1); dayIdx<=lastDay; dayIdx++) {
			if(dayIdx<1) {
				calendar.append("       ");
			}else {
				calendar.append(dayIdx<10? "   " + dayIdx : "  " + dayIdx);
				if(taskDays != null) {
					for(int taskDayIdx=0; taskDayIdx<taskDays.length; taskDayIdx++) {
						if(dayIdx == taskDays[taskDayIdx]) {
							isTask = true;
							break;
						}
					}
				}
				calendar.append(isTask?"+  ": "   ");
				isTask = false;
			}
			calendar.append((dayIdx+(dayOfWeek-1))%7==0? "\n      " : "");
			calendar.append(dayIdx==lastDay? "\n": "");
		}
		calendar.append("    (P : Previous month N : Next month Q : Quit)\n");
		return calendar.toString();
	}
}
