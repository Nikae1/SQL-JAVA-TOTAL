package client;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import server.ServerController;

public class UserApp {

	public UserApp() {
		frontController();
	}

	private void frontController() {
		Scanner scanner = new Scanner(System.in);
		String mainTitle = this.mainTitle(this.getToday(true, 0));
		String mainMenu = this.getMainMenu();
		boolean isLoop = true;
		String[] accessInfo = new String[2];
		boolean accessResult;
		ServerController ctl = new ServerController();
		TaskManagement task = null;
		String message = null;

		while (isLoop) {

			for (int idx = 0; idx < accessInfo.length; idx++) {
				this.display(mainTitle);
				this.display(this.getAccessLayer(true, accessInfo[0]));
				accessInfo[idx] = this.userInput(scanner);
			}
			this.display(this.getAccessLayer(false, null));

			String[] itemName = { "id", "password" };
			accessResult = ctl.controller(this.makeClientData("1", itemName, accessInfo)).equals("1") ? true : false;

			this.display(this.accessResult(accessResult));
			if (!accessResult) {
				/* 로그인 실패 */
				if (this.userInput(scanner).toUpperCase().equals("N")) {
					isLoop = false;
				} else {
					accessInfo[0] = null;
					accessInfo[1] = null;
				}
			} else {
				accessInfo[1] = null;
				while (isLoop) {
					String menuSelection = new String();
					while (true) {
						this.display(mainTitle);
						this.display(message != null ? "[Message : " + message + " ]\n" : "");
						this.display(mainMenu);

						menuSelection = this.userInput(scanner);
						if (this.isInteger(menuSelection)) {
							if (this.isIntegerRange(Integer.parseInt(menuSelection), 0, 4)) {
								break;
							} else {
								message = "메뉴는 0~4 범위내로 선택해주세요";
							}
						} else {
							message = "메뉴는 숫자로 입력해주세요";
						}
					}
					int month;
					if (menuSelection.equals("0")) {
						ctl.controller(this.makeClientData("-1", itemName, accessInfo));
						isLoop = false;
					} else {
						task = new TaskManagement();
						String[] subItemName = { "startDate", "endDate", "visibleType" };
						if (menuSelection.equals("1")) {
							String[] userSelection = { "    +++++++++++++++++++++++++++++++++++++ Start Date : ",
									"    +++++++++++++++++++++++++++++++++++++   End Date : ",
									"    +++++++++++++++++++++++++ Total  Enable  Disable : " };
							String[] userInput = new String[3];
							month = 0;
							while (true) {
								menuSelection = "11";

								this.display(mainTitle);
								this.display(message != null ? "   [ " + message + " ]\n" : "");

								this.display(task.taskController(Integer.parseInt(menuSelection), accessInfo[0], month)
										.toString());

								char direction = 'p';
								for (int idx = 0; idx < userInput.length; idx++) {
									this.display(userSelection[idx]);
									userInput[idx] = this.userInput(scanner).toUpperCase();

									if (this.isInteger(userInput[idx])) {
										if (!this.isIntegerRange(this.convertToInteger(userInput[idx]), 1,
												this.getLengthOfMonth(month))) {
											message = "검색 가능한 일자가 아닙니다.";
											direction = 'c';
											break;
										} else {
											message = null;
											direction = 'p';
										}
									} else {
										if (userInput[idx].equals("P") || userInput[idx].equals("N")) {
											month += userInput[idx].equals("P") ? -1 : 1;
											direction = 'c';
											break;
										} else if (userInput[idx].equals("Q")) {
											direction = 'b';
											break;
										} else if (idx == userInput.length - 1) {
											if (userInput[idx].equals("T") || userInput[idx].equals("E")
													|| userInput[idx].equals("D")) {
												message = null;
												direction = 'p';
											} else {
												message = "부적합한 메뉴입니다.";
												direction = 'c';
											}
										} else {
											message = "부적합한 메뉴입니다.";
											direction = 'c';
											break;
										}

									}
								}

								if (direction == 'b')
									break;
								if (direction == 'c')
									continue;

								userInput[0] = this.getDate(this.getToday(false, month), userInput[0], "");
								userInput[1] = this.getDate(this.getToday(false, month), userInput[1], "");

								String clientData = this.makeClientData("12", subItemName, userInput) + "&accessCode="
										+ accessInfo[0];
								this.display(mainTitle);
								this.display(task.taskController(clientData).toString());
								this.display("\n  ▶ ▷ ▶ ▷ ▶ ▷ ▶ ▷ ▶ ▷ ▶ ▷ ▶ ▷ ▶ ▷ ▶ ▷ ▶ ▷  More / Quit : ");
								if (this.userInput(scanner).toUpperCase().equals("Q"))
									break;
							}
						} else if (menuSelection.equals("2")) {
							String[] userSelection = { "    ++++++++++++++++++++++++++++++++++++ Select Date : ",
									"    ─────────────────────────────────── Confirm(Y/N) : " };
							String[][] item = { { "TIME Schedule(HHmmss)      : ", null },
									{ "ITEM CONTENT(THINGS TO DO) : ", null },
									{ "END DATE(yyyyMMddHHmmss)   : ", null } };
							message = null;
							menuSelection += "1";
							month = 0;
							int displayIdx = 0;
							int idx = 0; 
							String[] selectValue = { null, null };

							while (true) {
								this.display(mainTitle);
								this.display(message != null ? "   [ " + message + " ]\n" : "");
								this.display(task.taskController(Integer.parseInt(menuSelection), accessInfo[0], month)
										.toString());
								//달력을 보여준다.
								this.display(userSelection[0]);
								//날짜 등록. 시작일을 입력받기 위해 +++ Select Date : 를 띄워준다.

								if (selectValue[0] == null || selectValue[0].equals("P")
										|| selectValue[0].equals("N")) {
									selectValue[0] = this.userInput(scanner).toUpperCase();
									//시작일에 값이 없는경우 , p나 n이 들어가있는 경우는 재입력을 받는다.(p,n은 이전에 이미 실행하고 남아있음)
									if (selectValue[0].equals("Q")) {
										message = null;
										break;
									//시작일에 q를 받을 경우 메인메뉴로 돌아간다.
									} else if (selectValue[0].equals("P") || selectValue[0].equals("N")) {
										month += selectValue[0].equals("P") ? -1 : 1;
										continue;
										//시작일에 p와 n을 입력받은 경우 다시 시작일을 입력받는다. 위에 이미 실행하고 남아있는 경우가 이걸 선택한 경우다.
									}

								} else {
									//시작일에 p,n외에 값이 들어있는 경우 찍어준다.
									this.display(selectValue[0] + "\n");
								}
								
								if (this.isInteger(selectValue[0])) {
									//시작일이 정수값인지 확인한다.
									if (this.isIntegerRange(this.convertToInteger(selectValue[0]), 1,
											this.getLengthOfMonth(month))) {
										//시작일이 정수값인 경우 해당 달의 1일부터 마지막(30~31)일 까지인지 확인한다.
										this.display("\n");
										String date = this.getDate(this.getToday(false, month), selectValue[0], null);
										/*
										 * ex)시작일이 11월 5일일 경우 date=20221105가 된다. 
										 */
										this.display("     [ " + date + " ]  Item Registration\n");
										this.display("     ───────────────────────────────────────────────────\n");
										//11월 5일에 아이템을 등록한다.
										for (idx = 0; idx < item.length; idx++) {
											//item은 idx가 0일 때 시작일의 시간정보를 입력받는다. idx가 1일 때 할 일을 입력받는다.
											//idx가 3일 때 종료날짜를 입력받는다.
											this.display("      " + item[idx][0]);
											if (item[idx][1] == null) {
												String temp = this.userInput(scanner).toUpperCase();
												//위에 설명한 입력받을 곳은 각각 item[idx][0],item[idx][1],item[idx][2] 이다.
												if (temp.equals("Q")) {
													//언제든 Q를 입력받은 경우 반복문을 종료해준다.(for문)
													item[idx][1] = temp;
													message = null;
													break;
												}
												item[idx][1] = ((idx == 0) ? date : "") + temp;
												//0번인덱스일때는 시간정보를 입력받으므로 위에 date에 시간정보를 붙여줘서 yyyymmddhh24miss를 만들어준다.

											} else {
												this.display(item[idx][1] + "\n");
												//null이 아닐경우 보여줌
											}

											if (idx != 1) {
												if (!this.isDate(item[idx][1])) {
													//idx 0 ,2일때는 시작날짜와 끝나는 날짜이다. isDate를 통해 날짜형식으로 변환가능한지를 확인한다.
													//yyyymmddhh24miss로 변환불가능한 형식이면 오류메세지를 띄운다.
													item[idx][1] = null;
													message = "잘못된 입력입니다. 입력방식에 맞게 입력해주세요";
													break;
												} else {
													//변환가능하다면 convertToDate를 통해 변환해준다.
													
													item[idx][1] = this.convertToDate(item[idx][1]);
													if(idx==2&&Integer.parseInt(item[0][1].substring(7))>Integer.parseInt(item[idx][1].substring(7))) {
														item[idx][1] = null;
														message = "EndDate는 선택일보다 이후여야 합니다. ";
														break;
													}
												}
											}
										}
										/* 사용자 입력이 완료되지 않은 상태에 처리를 해준다.*/
										if (idx != item.length) {
											if (item[idx][1] == null)
												continue;
											if (item[idx][1].equals("Q"))
												break;
										}

										displayIdx += 1;
										//───────── Confirm(Y/N) : 입력받은 값을 확정할지 정한다.
										this.display(userSelection[displayIdx]);

										// Q Y N
										selectValue[1] = this.userInput(scanner).toUpperCase();
										if (selectValue[1].equals("Q") || selectValue[1].equals("N")) {
											//Q일경우 메인메뉴로 ,N일경우는 시작일은 그대로 다시 시간정보,할일,끝날짜를 입력받는다.
											message = null;
											for (idx = 0; idx < item.length; idx++) {
												item[idx][1] = null;
											}
											idx = 0;
											if (selectValue[1].equals("N")) {
												displayIdx = 0;
												valueNull(selectValue);
												continue;
											}
											if (selectValue[1].equals("Q"))
												break;
										} else if (selectValue[1].equals("Y")) {
											//Y일 경우 받은 정보를 가지고 할 일을 DB의 TODO 테이블에 넣어주기위해 클라이언트 데이터를 만들어준다.
											String[] regItemName = { "startDate", "endDate", "content", "accessCode" };
											String[] regItemValue = { item[0][1], item[2][1], item[1][1],
													accessInfo[0] };
											/* 클라이언트 데이터 예시)))))
											 * servicCode=22&startdate=20221106140000&endDate=20221106140000&contents=
											 * Programming&accessCode=LLL
											 */
											menuSelection = (Integer.parseInt(menuSelection) + 1) + "";
											Object object = null;

											object = task.taskController(
													this.makeClientData(menuSelection, regItemName, regItemValue));
											//client 데이터를 makeClientData를 통해 만들어줘서 서버로 보낸다.
											//서버에서는 Insert Into를 통해 할 일을 데이터베이스 TODO테이블에 넣어준다.
											//성공시 "1" , 실패시 "0"을 리턴한다.
											
											if (String.valueOf(object).equals("1")) {
												//1을 리턴했다면 INSERT가 성공했다.
												//성공했을 때 다시금 성공한 목록이 포함돼서 리스트가 출력이 된다.
												String cdata = "serviceCode=12&startDate=" + item[0][1].substring(0, 8)
														+ "&endDate=" + item[2][1].substring(0, 8)
														+ "&visibleType=T&accessCode=" + accessInfo[0];
												this.display(task.taskController(cdata).toString());
												menuSelection = "21";
												selectValue[1] = null;
												displayIdx = 0;
												idx = 0;
												for (idx = 0; idx < item.length; idx++) {
													item[idx][1] = null;
												}
												continue;

											} else {
												//0을 리턴했다면 실패메세지가 뜬다.
												message = "INSERT실패.";
												selectValue[1] = null;
												displayIdx = 0;
												idx = 0;
												continue;
											}

										} else {
											//QYN이 아닌 다른 명령어를 썼을 때
											message = "부적합한 명령입니다.";
											selectValue[1] = null;
											displayIdx = 0;
											idx = 0;
											continue;
										}

									} else {
										//해당 달의 날짜 외 일자를 선택했을 때 
										message = "검색 가능한 일자가 아닙니다.";
										idx = 0;
										valueNull(selectValue);
										continue;
									}
								} else {
									//숫자가 아닌 문자를 입력했을 때
									message = "숫자로 입력해주세요.";
									idx = 0;
									valueNull(selectValue);
									continue;
								}

								// break
							}

						} else if (menuSelection.equals("3")) {
							// 호원 3번 눌렀을 때 입력값을 받기위해 만든 배열들
							String[] userSelection = { "    ++++++++++++++++++++++++++++++++++++ Select Item : ",
									"    ──────────────────────────────────── More : ",
									"    ─────────────────────────────── SelectMonth(P/N) : ",
									"    ──────────────────────────────────── Select Modify : ",
									"    ++++++++++++++++++++++++++++++++++++ Select Day : ",
							"    ++++++++++++++++++++++++++++++++++++ End Day : "};
							String[] item = { "New StartDate(yyyyMMddHHmmss)      : ",
									"New END DATE(yyyyMMddHHmmss) : ", "New Content(Things to do)   : ",
									"New VisableType : ", "New Active State(A/I) : ",
									"New Feedback : " };
							message = null;
							menuSelection += "1";
							month = 0;					
							String[] selectValue = { null, null };
							String[] userInput = new String[3];
							Object object = null;
							
							while (true) {
								this.display(mainTitle);
								
								this.display(message != null ? "   [ " + message + " ]\n" : "");
								message = null;
								// 메세지가 있다면 메세지 출력
								this.display(task.taskController(Integer.parseInt(menuSelection), accessInfo[0], month)
										.toString());
								// 현재 달력 출력

								if(userInput[0]==null)
								{
									//시작 날짜와 끝나는 날짜를 받는데 null일때만 입력받게끔 한다.
									//둘 중 하나의 날짜가 null일경우는 정상적 출력이 된 것이 아니므로 마저 입력받게끔한다. 
									char direction = 'p';
									this.display(userSelection[4]);
									userInput[0] = this.userInput(scanner).toUpperCase();

									if (this.isInteger(userInput[0])) {
										if (!this.isIntegerRange(this.convertToInteger(userInput[0]), 1,
												this.getLengthOfMonth(month))) {
											//날짜범위가 아닐 경우 continue해준다.
											message = "검색 가능한 일자가 아닙니다.";
											direction = 'c';
											valueNull(userInput);
											break;
										} else {
											message = null;
											direction = 'p';
										}
									}else
									{
										//날짜범위일 경우 p와 n일경우 이전달 다음달을 새로 출력해주기 위해 continue
										//q를 입력받으면 break를 해준다.
										if (userInput[0].equals("P") || userInput[0].equals("N")) {
											month += userInput[0].equals("P") ? -1 : 1;
											direction = 'c';
											break;
										} else if (userInput[0].equals("Q")) {
											direction = 'b';
											break;
										} else {
											message = "부적합한 메뉴입니다.";
											direction = 'c';
											valueNull(userInput);
											break;
										}
									}
									if (direction == 'b')
										break;
									if (direction == 'c')
										continue;
									//제대로 입력받았으면 날짜 포맷에 맞춰서 날짜정보를 만들어준다.
									//visavle type은 t로 설정한다.
									userInput[0] = this.getDate(this.getToday(false, month), userInput[0], "");
									userInput[1] = userInput[0];
									userInput[2] = "T";
								}
								
	
								
								/* STEP 2 */
								//시작날짜 끝날짜 입력받은 정보를 이용해서 할 일 리스트를 불러온다.
								String clientData = this.makeClientData("12", subItemName, userInput) + "&accessCode="
										+ accessInfo[0];
								this.display(task.taskController(clientData).toString());
								//TaskManagement의 makeTodoList에서 setInfo(toDoList)를 통해서 필드의 list를 set해준다.
								//set해준 info를 get해준다.
								//할 일 목록이 없다면 taskmanagement의 getTaskListCtl에서 setnullInfo메서드를 통해서 필드의 list를 null로 바꿔준다
								object = task.getInfo();
			
								String[][] replace = (String[][]) object;
								
											
								//해당 달의 할일 목록이 있을 때 
								if (object != null) {
									
									this.display(userSelection[0]);
									//가져온 정보가 있다면 ++++++++++++++++++++++++++++++++++++ Select Item :
									
									//해당달의 달력과 날짜 할 일 리스트를 출력해주는데 다음달 이전달의 할 일을 보고 싶을 때
									if (selectValue[0] == null || selectValue[0].equals("P")
											|| selectValue[0].equals("N")) {
										selectValue[0] = this.userInput(scanner).toUpperCase();

										if (selectValue[0].equals("Q")) {
											message = null;
											break;
										} else if (selectValue[0].equals("P") || selectValue[0].equals("N")) {
											month += selectValue[0].equals("P") ? -1 : 1;
											continue;
										}

									} else {
										this.display(selectValue[0] + "\n");
									}
									
									if (this.isInteger(selectValue[0])) {
										// 수정할 번호로 입력받은 값이 숫자인지.
										if (this.isIntegerRange(this.convertToInteger(selectValue[0]), 0,
												replace.length - 1)) {
											// 수정할 번호로 입력받은 값이 수정할 목록 번호의 범위안에 들어올 때
											this.display("\n");
											message=null;
											int detailselectmenu=this.convertToInteger(selectValue[0]);
											
											// 은혜 3번 Modify 서브 메뉴 화면 출력용 메서드 
											this.display(this.modifySubMenu());
											
											String[] modInfo = new String[replace[detailselectmenu].length];
											
											this.display(userSelection[3]);
											// ────────────── Select Modify : 
											String temp=null;
											while (true) {
												//사용자가 q를 입력받을때까지 계속 수정한다.
												int menu =-1;
												if(temp == null)
												{
													temp = this.userInput(scanner).toUpperCase();
													scanner.nextLine();
												}
													
												
												if (temp.equals("S")) {
													this.display(item[0]);
													menu=0;
												} else if (temp.equals("E")) {
													this.display(item[1]);
													menu = 1;
												} else if (temp.equals("C")) {
													this.display(item[2]);
													menu = 2;
												} else if (temp.equals("V")) {
													this.display(item[3]);
													menu = 3;
												} else if (temp.equals("A")) {
													this.display(item[4]);
													menu = 4;
												} else if (temp.equals("F")) {
													this.display(item[5]);
													menu = 5;
												} else if (temp.equals("Q"))
													break;
												else
												{
													this.display("지정된 값이 아닙니다. \n");
													menu=-1;
												}
													
												
												
												if(menu != -1)
												{
													// feedback, contents와 같이 띄어쓰기 포함한 경우가 있을 수 있기때문에 nextLine을 써준다.
											 
													modInfo[menu] = this.userInputLine(scanner);
													
													if(modInfo[menu].toUpperCase().equals("Q"))
													{
														modInfo[menu] = null;
														break;
													}
														
												}
													
												if(menu ==0 || menu==1) //날짜 처리.
												{
													//날짜 수정정보를 입력받았을때 온전한 날짜 포멧으로 만들어준다.
													if (!this.isDate(modInfo[menu])) {
														modInfo[menu] = null;
														this.display("문자X, yyyymmdd까지는 입력해주세요. \n");
														continue;
													} else {
														modInfo[menu] = this.convertToDate(modInfo[menu]);
													}
												}
												else if(menu==3)
												{
													//ViusalType 예외처리
													if(!(modInfo[menu].equals("I") || modInfo[menu].equals("E")
															||modInfo[menu].equals("C") ))
													{
														modInfo[menu] = null;
														this.display("I(진행중),E(진행전),C(진행완료) 중 입력\n");
														continue;
													}
												}else if(menu==4)
												{
													//Active 예외처리
													if(!(modInfo[menu].equals("A") || modInfo[menu].equals("D")))				
													{
														modInfo[menu] = null;
														this.display("A(활성화),D(비활성화) 중 입력\n");
														continue;
													}
												}
												temp=null;
												// ────────────── More : 
												this.display(userSelection[1]);
											}
											int modcount=0;
											String detailnoStr="&detailno=";
											String detailconStr="&detailcontents=";
											for(int i=0; i<modInfo.length ; i++)
											{
												//modInfo에는 수정정보가 담기는데 null이 아닌 경우 count를 세고 query문에 필요한 정보를 만들어준다.
												if(modInfo[i] != null)
												{
													modcount++;
													detailnoStr+=(i+1)+",";
													detailconStr+=modInfo[i]+",";
												}
							
											}
											//수정정보가 없으면 서버에 보내줄 이유가 없음.
											if(modcount==0) break;
				
											//수정할 정보를 만들어준다.
											detailnoStr=detailnoStr.substring(0,detailnoStr.length()-1);
											detailconStr=detailconStr.substring(0,detailconStr.length()-1);
											
											clientData = "serviceCode=31&startDate="+replace[detailselectmenu][1]
													+"&endDate="+replace[detailselectmenu][2]
															+"&content="+replace[detailselectmenu][3]
															+"&visibleType="+replace[detailselectmenu][4]
															+"&active="+replace[detailselectmenu][5]
															+"&comments="+replace[detailselectmenu][6]
															+detailnoStr+"&accessCode="+accessInfo[0]+detailconStr;
											
											
											//수정할 정보를 서버에 보내주고 object로 받아온다.	
											object =task.taskController(clientData);
											//1,0값이 오는데 1이면 수정성공 0이면 수정실패이다.
											int modnum=Integer.parseInt(String.valueOf(object));
											if (modnum >=1) {
												this.display(modnum+"개 항목을 수정 했습니다. \n");
												//valueNull로 값들을 초기화해준다.
												valueNull(userInput,selectValue);
											}
											else
											{
												this.display("수정을 못했습니다.");
												break;
											}

										} else {
											//할 일 번호 외의 번호를 입력했을 때
											message = "아이템 목록에 없습니다.";								
											selectValue[0] = null;
											continue;
										}
									} else {
										//숫자 외 문자로 입력했을 때
										message = "숫자로 입력해주세요.";
										valueNull(userInput,selectValue);
										continue;
									}

								}
								else
								{
									//message = "";
									valueNull(userInput,selectValue);
									continue;
								}

								
							}

				

						} else if (menuSelection.equals("4")) {
							menuSelection += "1";

						}
					}
				}
			}
		}

		this.display("\n\n  x-x-x-x-x-x-x-x-x-x- 프로그램을 종료합니다 -x-x-x-x-x-x-x-x-x-x");
		scanner.close();

	}
	// 현우 유저 입력값을 초기화 하기위한 메서드
	private void valueNull(String[] val1)
	{
		for(int i=0; i<val1.length ; i++)
		{
			val1[i]=null;
		}
		
	}
	private void valueNull(String[] val1 , String[] val2)
	{
		for(int i=0; i<val1.length ; i++)
		{
			val1[i]=null;
		}
		for(int i=0; i<val2.length ; i++)
		{
			val2[i]=null;
		}
	}
	// 은혜 3번 Modify 서브 메뉴 화면 출력용 메서드 
	private String modifySubMenu() {
		StringBuffer subMenu = new StringBuffer();

		subMenu.append("─────────────────────────────────────────────────────────────────────────────────\n");
		subMenu.append("  StartDate(S)  EndDate(E) Content(C)  Vtype(V)  Active(A)  FeedBack(F)  Quit(Q) \n");
		subMenu.append("─────────────────────────────────────────────────────────────────────────────────\n");

		return subMenu.toString();
	}

	/* 정수 변환여부 체크 */
	private boolean isInteger(String value) {
		boolean isResult = true;
		try {
			Integer.parseInt(value);
		} catch (Exception e) {
			isResult = false;// e.printStackTrace();
		}
		return isResult;
	}

	/* 문자 >> 정수 변환 */
	private int convertToInteger(String value) {
		return Integer.parseInt(value);
	}

	/* 정수의 범의 체크 */
	private boolean isIntegerRange(int value, int starting, int last) {
		return (value >= starting && value <= last) ? true : false;
	}

	private String makeClientData(String serviceCode, String[] item, String[] userData) {
		StringBuffer clientData = new StringBuffer();
		clientData.append("serviceCode=" + serviceCode);
		for (int idx = 0; idx < userData.length; idx++) {
			if (userData[idx] != null) {
				clientData.append("&");
				clientData.append(item[idx] + "=" + userData[idx]);
			}
		}
		return clientData.toString();
	}
	////은혜 메인타이틀 화면 출력 디자인
	private String mainTitle(String date) {
		StringBuffer title = new StringBuffer();
		title.append(" ===============================================================\n");
		title.append("│  ______  _                                               \t│\n"
				   + "│  | ___ \\| |                                             \t│\n"
				   + "│  | |_/ /| |  __ _  _ __   _ __    ___  _ __              \t│\n"
				   + "│  |  __/ | | / _` || '_ \\ | '_ \\  / _ \\| '__|            \t│\n"
				   + "│  | |    | || (_| || | | || | | ||  __/| |                  \t│\n"
				   + "│  \\_|    |_| \\__,_||_| |_||_| |_| \\___||_|               \t│\n");
		title.append("│                                                            \t│\n");
		title.append("│                                                            \t│\n");
		title.append("│ 1조 이정한_정현우_김호원_송은혜               "+date+"         \t│\n");
		title.append("│                                                            \t│\n");
		title.append("│                                                               │\n");                 
		title.append(" ===============================================================\t\t\n");
		title.append("\n");
		return title.toString() ;
	}
	/* 프로그램 메인 타이틀 제작 */
//	private String mainTitle(String date) {
//		StringBuffer title = new StringBuffer();
//		
//		
//		title.append("\n\n\n");
//		title.append("  __________________________________________________________\n\n");
//		title.append("     ◀▷◀▷◀▷◀▷◀▷◀▷◀▷◀▷◀▷\n");
//		title.append("        T A S K\n");
//		title.append("        M A N A G E R                   " + date + "\n");
//		title.append("     ◀▷◀▷◀▷◀▷◀▷◀▷◀▷◀▷◀▷        1조 이정한_정현우_김호원_송은혜\n");
//		title.append("  __________________________________________________________\n");
//
//		return title.toString();
//	}

	private String getAccessLayer(boolean isItem, String accessCode) {
		StringBuffer accessLayer = new StringBuffer();

		if (isItem) {
			accessLayer.append("\n");
			accessLayer.append("     Access ++++++++++++++++++++++++++++++++++++++++++\n");
			accessLayer.append("     +        AccessCode          SecretCode\n");
			accessLayer.append("     + --------------------------------------------\n");
			accessLayer.append("     +         " + ((accessCode != null) ? accessCode + "\t\t" : ""));
		} else {
			accessLayer.append("     +++++++++++++++++++++++++++++++++++ Connecting...");
		}
		return accessLayer.toString();
	}

	/* 서버응답에 따른 로그인 결과 출력 */
	private String accessResult(boolean isAccess) {
		StringBuffer accessResult = new StringBuffer();

		accessResult.append("\n     >>>>>>>>>>>>>>>>>>>>>>>>> ");
		if (isAccess) {
			accessResult.append("Successful Connection\n");
			accessResult.append("     Move after 2 sceonds...\n");
		} else {
			accessResult.append("Connection Failed\n");
			accessResult.append("     _______________________________ Retry(y/n) ? ");
		}

		return accessResult.toString();
	}

	/* 메인페이지 출력 */
	private String getMainMenu() {
		StringBuffer mainPage = new StringBuffer();

		mainPage.append("\n");
		mainPage.append("     [ MENU SELECTION ] __________________________________\n\n");
		mainPage.append("       1. TASK LIST		2. TASK REGISTRATION\n");
		mainPage.append("       3. MODIFY TASK		4. TASK STATS\n");
		mainPage.append("       0. DISCONNECT    \n");
		mainPage.append("     ________________________________________________ : ");

		return mainPage.toString();
	}

	/* 날짜시간 출력 : LocalDateTime Class + DateTimeFormatter Class */
	private String getToday(boolean isDate, int month) {
		String pattern = (isDate) ? "yyyy. MM. dd." : "yyyyMM";
		return LocalDateTime.now().plusMonths(month).format(DateTimeFormatter.ofPattern(pattern));
	}

	/* 선택한 일자에 해당하는 날짜 구하기 */
	private String getDate(String yearMonth, String day, String time) {
		String date = (day.length() == 1) ? yearMonth + "0" + day : yearMonth + day;
		return date += (time == null) ? "" : time;
	}

	/* 날짜 변환 가능 여부 */
	private boolean isDate(String value) {
		boolean result = false;
		int year, month, day = 1, hour = 0, minute = 0, second = 0;
		int length = value.length();
		if ((length >= 8 && length <= 14) && length % 2 == 0) {
			year = Integer.parseInt(value.substring(0, 4));
			month = Integer.parseInt(value.substring(4, 6));
			if (length == 8)
				day = Integer.parseInt(value.substring(6));
			if (length > 8)
				day = Integer.parseInt(value.substring(6, 8));
			if (length == 10)
				hour = Integer.parseInt(value.substring(8));
			if (length > 10)
				hour = Integer.parseInt(value.substring(8, 10));
			if (length == 12)
				minute = Integer.parseInt(value.substring(10));
			if (length > 12)
				minute = Integer.parseInt(value.substring(10, 12));
			if (length == 14)
				second = Integer.parseInt(value.substring(12));

			try {
				LocalDateTime.of(year, month, day, hour, minute, second);
				result = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return result;
	}

	/* 날짜 형식 변환(yyyyMMdd, yyyyMMddHH, yyyyMMddHHmm, yyyyMMddHHmmss) */
	private String convertToDate(String value) {
		String formattedDate = value;

		switch (value.length()) {
		case 8:
			formattedDate += "000000";
			break;
		case 10:
			formattedDate += "0000";
			break;
		case 12:
			formattedDate += "00";
			break;
		}

		return formattedDate;
	}

	/* 선택한 달의 일수 구하기 */
	private int getLengthOfMonth(int month) {
		return LocalDate.now().plusMonths(month).lengthOfMonth();
	}

	/* 사용자 입력 */
	private String userInput(Scanner scanner) {
		return scanner.next();
	}
	// 은혜 유저 공백 포함 입력받기 위한 메서드
	private String userInputLine(Scanner scanner) {
		return scanner.nextLine();
	} 
	/* 화면 출력 */
	private void display(String text) {
		System.out.print(text);
	}
}
